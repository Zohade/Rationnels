Fonctionnalit�s du programme Nombres Rationnels

1-Diff�rentes classes impliqu�s :
-Classe Rationnel : Qui repr�sente un nombre rationnel sous sa forme ordinaire ;
-Classe Rationnel Normalis� : Qui repr�sente un nombre rationnel apr�s derni�re simplification possible (pgcd (num�rateur, d�nominateur) =1).

2-Les diff�rentes m�thodes /fonctions par classe et leurs r�les
*	Classe Rationnel :

- Rationnel (Int tab [2]) ;
Constructeur de la classe Rationnel prenant un tableau.

- Rationnel (int num, int den);
Constructeur prenant deux entiers.

- Rationnel (int num) ;
 Constructeur de la classe Rationnel prenant un entier. Le d�nominateur � 1 par d�faut

- Rationnel () ;
Constructeur d'un nombre rationnel par d�faut qui le met � 0/1.

- Rationnel(StructRationnel toi) ;
Constructeur d'un nombre rationnel � partir d'une structure

- Rationnel Addition (Rationnel b) ;
      Addition entre deux rationnels
- Rationnel Addition(int b) ;
Addition entre rationnel et un entier.

- Rationnel Multi(Rationnel b) ;
Multiplication entre deux rationnels 
- Rationnel Multi(int b);

      Multiplication entre un rationnel et un nombre entier 

-  Rationnel Division(Rationnel b) ;
Division entre deux rationnels ;
   -   Rationnel Division (int b);
      Division entre un rationnel et un entier.
   -   double Division () ;
      Division standard : fonction interm�diaire .

- Rationnel Soustraction (Rationnel b) ;
Soustraction entre deux rationnels.
- Rationnel Soustraction (int b) ;
Soustraction entre un rationnel et un entier.
- void Affichage();
      Affichage d'un nombre rationnel sous sa forme fractionnelle.
- Rationnel Inverse () ;
Inverse d'un rationnel.
- Rationnel Inverse (int b) ;
Inverse d'un entier. 
- Rationnel Normaliser ();
Normalisation d'un rationnel : rendre sous forme non simplifiable.
- Rationnel SommeRationnels (int n);
Sommes de n nombres rationnels.

- MultiRationnels (int n) ;
      Multiplication de n nombres rationnels.
- int Comparaison (Rationnel b);
      Comparaison de deux rationnels
- void Trieuse();
      Tri de n nombres rationnels.

*	Classe RationnelNormalise :

- RationnelNormalise (int tab[2]);
     Constructeur prenant un tableau de taille 2.

- RationnelNormalise (int num, int den);
      Constructeur de rationnel avec un num�rateur et un d�nominateur.

- RationnelNormalise (int num); 
Constructeur d'un rationnel � partir de entier relatifs(d�nominateur 1 par d�faut).

- RationnelNormalise();
      Constructeur par d�faut initialisant le rationnel normalis�.

- RationnelNormalise (StructRationnel toi);
      Constructeur utilisant une structure

- RationnelNormalise Addition (RationnelNormalise b);
       Pour l'addition entre 2 rationnels.

- RationnelNormalise Multi(RationnelNormalise b);
      Pour la multiplication entre deux rationnels

- RationnelNormalise Division(RationnelNormalise b);
      Pour la division entre 2�rationnels normalis�s.

- RationnelNormalise Soustraction(RationnelNormalise b);
Pour la soustraction entre deux rationnels normalis�s.

- void Affichage();
      Pour l'affichage d'un rationnel sous sa forme fractionnelle
- RationnelNormalise Inverse ();
      Inversion d'un rationnel

- double Division();
      Une division interne de deux entiers.

- int Comparaison(RationnelNormalise b);
     Comparaison de deux rationnels.

- void Trieuse();
      Pour le tri croissant de n rationnels.


*	Autres fonctions

- StructRationnel Recuperation();
     Qui prend les param�tres au clavier et construire une structure.

- bool verifier(int b); 
fonction qui v�rifie si le d�nominateur est sup�rieur � 0.
 
- int pgcd(int a, int b);
      Retourne le pgcd de deux entiers.

- void tri (vector<double>tab);
     Pour le tri des �l�ments d'un tableau d'entiers.

R�sum�
Pour faciliter l'utilisation de notre programme avec le user, un menu � choix 
multiples a �t� propos� au lancement du programme ; le user n'aura qu'� 
choisir l'op�ration qu'il d�sire r�aliser sur les rationnels.
