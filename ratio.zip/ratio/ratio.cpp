#include "ratio.h"

//createur de ratio avec deux parametres
StructRationnel Recuperation(){
    StructRationnel moi;
    cout<<" Entrer le numerateur  : ";
    cin>>moi.num;
    cout<<" Entrer le denoninateur  : ";
    cin>>moi.den;
    while(moi.den==0){
        cout<<"Denominateur doit etre different de 0\n";
        cin>>moi.den;
    }
    return moi;
}
//Fonction qui vérifie si une variable!=0
bool verifier(int b){
    return {(b!=0)?true:false};
    }
    //calcul le pgcd de deux entiers
    int pgcd(int a, int b){
    while (b != 0)
    {
    const int t = b;
    b = a%b;
    a=t;
}
return a;
}

void tri(vector<double>tab){ //fonction trieuse basée sur l'algorithme de tri
    double min;
    for(unsigned int i=0;i<tab.size();i++)
    {
        for( unsigned int j=0;j<tab.size();j++)
        {
            if(tab[j]<tab[j+1])
            {
                min=tab[j];
                tab[j]=tab[j+1];
                tab[j+1]=min;

            }
            if(tab[j]>tab[j+1])
            {
                min=tab[j+1];
                tab[j+1]=tab[j];
                tab[j]=min;
            }
        }

    }
    cout<<"tab=[";

    for( unsigned int i=0;i<tab.size();i++)
    {
        if(i!=(tab.size()-1)){
            cout<<tab[i+1]<<",";
        }else{
            cout<<tab[i+1];

        }
    }
    cout<<"]"<<endl;

}


                   //methodes de la classe Rationnel

//constructeur prenant un tableau
Rationnel::Rationnel(int tab[2]){
    if(verifier(tab[1])){
        r[0]=tab[0];
        r[1]=tab[1];
    }else{
        cout<<"Erreur!!!Le denominateur doit etre different de 0\n";
    }
}

//constructeur prenant une structure
Rationnel::Rationnel(StructRationnel toi){
    if(verifier(toi.den)){
        r[0]=toi.num;
        r[1]=toi.den;
    }else{
        while(toi.den==0){
            cout<<"Votre denominateur doit etre different de 0\n";
            cin>>toi.den;
        }
        r[0]=toi.num;
        r[1]=toi.den;
    }
}

//constructeur prenant deux entiers
Rationnel::Rationnel(int num, int den){
    if(verifier(den)){
        r[0]=num;
        r[1]=den;
    }else{
        cout<<"Erreur!!!Le denominateur doit etre different de 0";
    }
}

//constructeur prenant un entier(numérateur)
Rationnel::Rationnel(int num){
    r[0]=num;
    r[1]=1;
}

//constructeur par défaut
Rationnel::Rationnel(){
    r[0]=0;
    r[1]=1;
}

//operations standards

Rationnel Rationnel::Addition(Rationnel b){//addition entre deux rationels
    Rationnel result;
    result.r[0]=(r[0]*b.r[1])+(r[1]* b.r[0]);
    result.r[1]=(r[1]*b.r[1]);

    return result;
}
Rationnel Rationnel::Addition(int b){//addition entre rationel et entier
    Rationnel result;
    result.r[0]=r[0]+r[1]*b;
    result.r[1]=r[1];
    return result;
}

Rationnel Rationnel::Multi(Rationnel b){//multiplictaion entre deux rationnels

    Rationnel result;
    result.r[0]=r[0]*b.r[0];
    result.r[1]=r[1]*b.r[1];
    return result;
}

Rationnel Rationnel::Multi(int b){ //Multiplication entre rationnel et entier
    Rationnel result;
    result.r[0]=r[0]*b;
    result.r[1]=r[1];

    return result;
}
Rationnel Rationnel::Division(Rationnel b){ //Division d'un rationnel par un rationnel
    if(b.r[0]!=0){
        this->Multi(b.Inverse());

    }else{
        cout<<"La division est impossible\n";
        exit(1);
    }
}

Rationnel Rationnel::Division(int b){ //Division d'un rationnel par un entier
    if(b!=0){
        this->Multi(Inverse(b));

    }else{
        cout<<"la division est impossible\n";
        exit(1);
    }

}
double Rationnel::Division(){ //division interne entre deux valeurs

    double num=r[0];
    double den=r[1];
    return num/den;
}


Rationnel Rationnel::Soustraction(Rationnel b){ //Soustraction entre deux rationnels
    Rationnel result;
    result.r[0]=(r[0]*b.r[1])-(r[1]* b.r[0]);
    result.r[1]=(r[1]*b.r[1]);
    return result;
}

Rationnel Rationnel::Soustraction(int b){ //Soustraction entre unnrationnel et un entier
    Rationnel result;
    result.r[0]=r[0]-(r[1]* b);
    result.r[1]=r[1];
    return result;
}

void Rationnel::Affichage(){ //Affichage de rationnel sous forme fractionnelle
    cout<<"Votre nombre est : "<<r[0]<<"/"<<r[1]<<endl;
}
//Autres operations
Rationnel Rationnel::Inverse(){ //inverse d'un rationnel
    if(r[0]!=0){
        int a;
        a=r[0];
        r[0]=r[1];
        r[1]=a;
        return * this;
    }else{
        cout<<"La fraction n\'est pas inversible ";
    }
}

Rationnel Rationnel::Inverse(int b){ //inverse d'un entier
    if(b!=0){
        Rationnel entier_inverse;
        entier_inverse.r[0]=1;
        entier_inverse.r[1]=b;
        return entier_inverse;
    }else{
        cout<<"l\'inverse de votre nombre n\'hesiste pas";
    }
}

Rationnel Rationnel::Normaliser(){ //normalisation
    int t =pgcd(r[0],r[1]);

    r[0]=r[0]/t;
    r[1]=r[1]/t;
    return * this;
}

Rationnel Rationnel:: SommeRationnels(int n) //Sommes sucessives de n rationnels
{
    Rationnel resultat(0,1);
    for(int i=0;i<n;i++)
    {

        int tab[2];
        cout<<"Entrez le numerateur du nombre"<<i+1<<" : ";
        cin>>tab[0];
        cout<<"Entrez le denominateur du nombre"<<i+1<<" : ";
        cin>>tab[1];
        while (tab[1]==0)
        {
            cout<<"Assurez vous d\entrer un denominateur different de zero"<<"Recommencez"<<endl;
            cin>>tab[1];
        }

        Rationnel rationnel(tab);
        resultat=resultat.Addition(rationnel);



    }

    return resultat;
}


Rationnel Rationnel:: MultiRationnels(int n)//Multiplications sucessives n rationnels
{
    Rationnel resultat(1,1);
    for(int i=0;i<n;i++)
    {

        int tab[2];
        cout<<"Entrez le numerateur du nombre"<<i+1<<" : ";
        cin>>tab[0];
        cout<<"Entrez le denominateur du nombre"<<i+1<<" : ";
        cin>>tab[1];
        while (tab[1]==0)
        {
            cout<<"Assurez vous d\entrer un denominateur different de zero\n"<<"Recommencez"<<endl;
            cin>>tab[1];
        }

        Rationnel rationnel(tab);
        resultat=resultat.Multi(rationnel);



    }

    return resultat;
}

int Rationnel::Comparaison(Rationnel b){ //comparaison entre rationnels
    if(r[1]==b.r[1]){
        return {(r[0]<b.r[0])?1:0};
        }else{
        return{(this->Division()<b.Division())?1:0};
}

}

void Rationnel:: Trieuse() //Pour le tri de Rationnels
{
    int n;
    cout<<"Combien de nombres voulez vous trier?"<<endl;
    cin>>n;
    vector <double> tab;

    for(int i=0;i<n;i++)
    {
        cout<<" fraction "<<i+1<<" : ";
        Rationnel ratio(Recuperation());
        tab.push_back(ratio.Division());


    }
    tri(tab);
}



//methodes de la classe RationnelNormalise pour les rationnles dont le pgcd est 1

RationnelNormalise::RationnelNormalise(int num, int den){ //constructeur à deux entiers

    if(pgcd(num,den)==1){
        if(den<0){
            r[0]=(-1*num);
            r[1]=fabs(den);
        }else if(den>0){
            r[0]=num;
            r[1]=den;
        }else{
            cout<<"Erreur!!!Le denominateur doit etre different de 0";
        }
    }else{
        while(pgcd(num,den)!=1){
            cout<<"votre rationnel "<<num<<"/"<<den<<" n\'est pas normalise\n Assurez-vous que le pgcd soit egal a 1\n";
            cout<<"renseigner a nouveau le numerateur de votre rationnel : ";
            cin>>num;
            cout<<"renseigner a nouveau le denominateur de votre rationnel : ";
            cin>>den;
            while(den==0){
                cout<<"Votre denominateur doit etre different de 0\n";
                cin>>den;
            }
        }
        r[0]=num;
        r[1]=den;

    }
}
RationnelNormalise::RationnelNormalise(int tab[2]) //constructeur à tableau
{
    RationnelNormalise(tab[0],tab[1]);
}
RationnelNormalise::RationnelNormalise(int num){ //constructeur prenant un entier
    RationnelNormalise(num,1);
}
RationnelNormalise::RationnelNormalise(StructRationnel toi){ //constructeur prenant une structure

    if(verifier(toi.den)){
        r[0]=toi.num;
        r[1]=toi.den;
    }else{
        while(toi.den==0){
            cout<<"Votre denominateur doit etre different de 0\n";
            cin>>toi.den;
        }
        r[0]=toi.num;
        r[1]=toi.den;
    }
}

RationnelNormalise::RationnelNormalise() //constructeur par défaut
{
    RationnelNormalise(0,1);
    }
//Operation standard

RationnelNormalise RationnelNormalise::Addition(RationnelNormalise b){ //addition entre deux rationnels normalisés
    RationnelNormalise result;
    result.r[0]=(r[0]*b.r[1])+(r[1]* b.r[0]);
    result.r[1]=(r[1]*b.r[1]);
    int t= pgcd(result.r[0],result.r[1]);
    result.r[0]=result.r[0]/t;
    result.r[1]=result.r[1]/t;

    return result;
}

RationnelNormalise RationnelNormalise::Multi(RationnelNormalise b){//multiplictaion entre deux rationnels normalisés

    RationnelNormalise result;
    result.r[0]=r[0]*b.r[0];
    result.r[1]=r[1]*b.r[1];
    int t= pgcd(result.r[0],result.r[1]);
    result.r[0]=result.r[0]/t;
    result.r[1]=result.r[1]/t;
    return result;
}

RationnelNormalise RationnelNormalise::Division(RationnelNormalise b){//division entre deux rationnels normalisés
    if(b.r[0]!=0){
        this->Multi(b.Inverse());

    }else{
        cout<<"La division est impossible\n";
        exit(1);
    }
}
double RationnelNormalise::Division(){ //division interne entre deux valeurs

    double num=r[0];
    double den=r[1];
    return num/den;
}

RationnelNormalise RationnelNormalise::Soustraction(RationnelNormalise b){ //Soustraction entre deux rationnels normalisés
    RationnelNormalise result;
    result.r[0]=(r[0]*b.r[1])-(r[1]* b.r[0]);
    result.r[1]=(r[1]*b.r[1]);
    int t= pgcd(result.r[0],result.r[1]);
    result.r[0]=result.r[0]/t;
    result.r[1]=result.r[1]/t;
    return result;
}

void RationnelNormalise::Affichage(){ //Affichage rationnels Normalisés
    cout<<"Votre nombre est : "<<r[0]<<"/"<<r[1]<<endl;
}
RationnelNormalise RationnelNormalise::Inverse(){ //Inversion de rationnels normaliés
    int a;
    RationnelNormalise inverse;
    a=r[0];
    inverse.r[0]=r[1];
    inverse.r[1]=a;
    return inverse;
}
int RationnelNormalise::Comparaison(RationnelNormalise b){ //comparaison entre rationnels
    if(r[1]==b.r[1]){
        return {(r[0]<b.r[0])?1:0};
        }else{
        return{(this->Division()<b.Division())?1:0};
}
}

void RationnelNormalise::Trieuse(){
    int n;
    cout<<"Combien de nombres voulez vous trier?"<<endl;
    cin>>n;
    vector <double> tab;

    for(int i=0;i<n;i++)
    {
        int num,den;
        cout<<"Entrer le numerateur de la fraction "<<i+1<<" : ";
        cin>>num;
        cout<<"Entrer le denominateur de la fraction "<<i+1<<" : ";
        cin>>den;
        RationnelNormalise ratio(num,den);
        tab.push_back(ratio.Division());


    }
    tri(tab);
}
